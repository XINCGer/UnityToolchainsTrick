﻿using System;
using System.Collections.Generic;
using System.IO;
using Bolygon.BuildPlugin;
using Bolygon.BuildPlugin.Tool;
using UnityEditor;
using UnityEngine;

namespace BolygonTool.Check
{
    public class PackageImportCheck
    {
        private static PackageCheckSetting Setting => PackageCheckSetting.Instance;
        public static Action CheckCompleted;
        public static void CheckPackage(string packagePath)
        {
            AssetDatabase.ImportPackage(packagePath,false);
        }


        [InitializeOnLoadMethod]
        static void RegisterImportPackageCallback()
        {
            AssetDatabase.onImportPackageItemsCompleted += ItemImportComplete;
            AssetDatabase.importPackageFailed += ImportFail;
        }

        private static void ImportFail(string packagename, string errormessage)
        {
            CloudBuildLog.Error($"Import {packagename} Failed!! {errormessage}",false);
            Setting.CheckInfo = new PackageCheckInfo
            {
                UnsupportInfo = new UnsupportInfo {HasScript = true, HasUnSupportShader = true}
            };
            CheckCompleted?.Invoke();
        }
        
        private static void ItemImportComplete(string[] objs)
        {
            if(!EditorPrefs.GetBool(CheckPackagePref.CheckTrigger, false)) return;
            
            var checkRes = new PackageCheckInfo{PackageName = Setting.PackageName, UnsupportInfo = new UnsupportInfo()};
            var prefabs = new List<string>();
            var materials = new List<string>();
            
            string _mat = ".mat";
            string _prefab = ".prefab";
            string _dll = ".dll";
            string _cs = ".cs";
            foreach (var s in objs)
            {
                if (s.EndsWith(_cs) || s.EndsWith(_dll))
                {
                    checkRes.UnsupportInfo.HasScript = true;
                    break;
                }

                if (s.EndsWith(_mat))
                {
                    materials.Add(s);
                }
                else if (s.EndsWith(_prefab))
                {
                    prefabs.Add(s);
                }
            }

            if (!checkRes.UnsupportInfo.InVaild())
            {
                if (prefabs.Count > 0)
                {
                    var prefabInfos = new List<PrefabCheckInfo>();
                    checkRes.PrefabInfos = prefabInfos;
                    foreach (var s in prefabs)
                    {
                        var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(s);
                        if (prefab == null) continue;
                        var renders = prefab.GetComponentsInChildren<Renderer>();
                        if (renders.Length <= 0)
                            continue;

                        var item = new PrefabCheckInfo
                            {Path = s, MaterialInfos = new List<MaterialCheckInfo>(), Logs = new List<string>()};
                        foreach (var render in renders)
                        {
                            foreach (var mat in render.sharedMaterials)
                            {
                                if (mat == null)
                                    continue;
                                var materialInfo =
                                    CheckIsUnsupportShader(mat, AssetDatabase.GetAssetPath(mat), checkRes);
                                item.MaterialInfos.Add(materialInfo);
                                if (materialInfo.Type == ShaderType.Unknown)
                                    item.Logs.Add($"{materialInfo.Name} has unknown shader");
                                else if (materialInfo.Type == ShaderType.BuiltInStandard)
                                    item.Logs.Add($"{materialInfo.Name}'s shader is stand");
                                else if (materialInfo.Type == ShaderType.StandardCustom)
                                    item.Logs.Add($"{materialInfo.Name}'s shader is stand custom");
                            }
                        }

                        prefabInfos.Add(item);
                    }
                }

                if (materials.Count > 0)
                {
                    var matInfos = new List<MaterialCheckInfo>();
                    checkRes.MaterialInfos = matInfos;
                    foreach (var s in materials)
                    {
                        matInfos.Add(
                            CheckIsUnsupportShader(AssetDatabase.LoadAssetAtPath<Material>(s), s, checkRes));
                    }
                }
            }

            Setting.CheckInfo = checkRes;
            Setting.Refresh();
            CheckCompleted?.Invoke();
        }

        private static MaterialCheckInfo CheckIsUnsupportShader(Material mat, string matP, PackageCheckInfo checkRes)
        {
            var res = new MaterialCheckInfo {Name = mat.name, ShaderName = mat.shader.name};

            if (matP.StartsWith("Packages/com.unity.render-pipelines.universal"))
            {
                res.Type = ShaderType.BuiltInUrp;
            }
            else if (matP.StartsWith("Resources"))
            {
                res.Type = ShaderType.BuiltInStandard;
            }
            else
                res.Type = ShaderChecker.CheckShader(mat.shader);

            if (res.Type == ShaderType.Unknown)
            {
                checkRes.UnsupportInfo.HasUnSupportShader = true;
                res.Logs = new List<string> {"UnKnown shader"};
            }
            else if ( res.Type == ShaderType.BuiltInUrp || res.Type == ShaderType.URPCustom)
                res.Logs = new List<string> {"pass"};
            else if (res.Type == ShaderType.BuiltInStandard || res.Type == ShaderType.StandardCustom)
            {
                res.Logs = new List<string> {"not is urp"};
                checkRes.UnsupportInfo.HasUnSupportShader = true;
            }
            
            return res;
        }

        private static void CheckHotScript(List<MonoBehaviour> monoList, GameObject go)
        {
            var scripts = go.GetComponentsInChildren<MonoBehaviour>(true);
            if (scripts == null || scripts.Length == 0) return;
            foreach (var mono in scripts)
            {
                if (mono == null) continue;
                //if (CheckAssetTool.IsHotfixScript(mono.GetType()))
                //{
                    monoList.Add(mono);
                //}
            }
        }
        
        public class CheckPackagePref
        {
            private static bool loaded;
            private static bool isClear;
            private static bool isCheck;
            public const string ClearTrigger = "ClEAR_TRIGGER";
            public const string CheckTrigger = "CHECK_TRIGGER";
            [SettingsProvider]
            private static SettingsProvider ToolChainsTrickSetting()
            {
                var provider = new SettingsProvider("Preferences/CheckPackageSetting", SettingsScope.User)
                {
                    guiHandler = (string key) => { PreferenceGUI(); },
                    keywords = new string[] {"Check", "Package"},
                };
                return provider;
            }

            private static void PreferenceGUI()
            {
                if (!loaded)
                {
                    Load();
                }
                EditorGUI.BeginChangeCheck();
                isClear = EditorGUILayout.Toggle("是否自动Check Package", isClear, GUILayout.Width(200));
                if (EditorGUI.EndChangeCheck())
                {
                    EditorPrefs.SetBool(CheckTrigger, isCheck);
                }
            
                EditorGUI.BeginChangeCheck();
                isClear = EditorGUILayout.Toggle("导入包后是否清理Asset文件夹", isClear, GUILayout.Width(250));
                if (EditorGUI.EndChangeCheck())
                {
                    EditorPrefs.SetBool(ClearTrigger, isClear);
                }
            }
        
            private static void Load()
            {
                isClear = EditorPrefs.GetBool(ClearTrigger, false);
                isCheck = EditorPrefs.GetBool(CheckTrigger, false);
                loaded = true;
            }
        }

    }
}