//---------------------------------------------------------------------------------------
// Author: chenxuan@bolygon.com
// Date: 2021-09-01 14:54:40
// Name: ShaderChecker
//---------------------------------------------------------------------------------------

using System.IO;
using BolygonTool.Check;
using UnityEditor;
using UnityEngine;

namespace Bolygon.BuildPlugin.Tool
{
    public enum ShaderType
    {
        BuiltInStandard,
        BuiltInUrp,
        StandardCustom,
        URPCustom,
        Unknown,
    }

    public static class ShaderChecker
    {
        public static ShaderType CheckShader(Shader shader)
        {
            string path = AssetDatabase.GetAssetPath(shader);
             
            if (string.IsNullOrEmpty(path))
            {
                return ShaderType.Unknown;
            }
            
            if (path.StartsWith("Packages/com.unity.render-pipelines.universal"))
            {
                return ShaderType.BuiltInUrp;
            }
            
            if (path.StartsWith("Resources"))
                return ShaderType.BuiltInStandard;
            
            if (!File.Exists(path))
                return ShaderType.Unknown;
            
            //是ShaderGraph
            if (Path.GetExtension(path) == ".shadergraph")
            {
                return ShaderType.URPCustom;
            }
            //对Shader文本进行分析
            using (StreamReader sr = new StreamReader(path))
            {
                var shaderTxt = sr.ReadToEnd();
                shaderTxt = shaderTxt.Replace("\n", "").Replace(" ", "");
                //判断是不是BuiltIn
                if (ShaderRuleConfig.IsBulitInShader(shaderTxt))
                    return ShaderType.StandardCustom;
                //判断是不是URP
                if (ShaderRuleConfig.IsURPShader(shaderTxt))
                    return ShaderType.URPCustom;
            }

            return ShaderType.Unknown;
        }
    }
}