using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;

namespace Bolygon.BuildPlugin.Tool
{
    public class ShaderRuleConfig : ScriptableObject
    {
        public List<string> BuiltInRuleList;
        public List<string> URPRuleList;

        private const string configPath = "Assets/Editor/PackageCheck/ShaderRuleConfig.asset";
        
        [MenuItem("Assets/Create/Shader/ShaderRuleConfig", priority = 0)]
        public static void CreateShaderRuleConfig()
        {
            if (Selection.assetGUIDs.Length <= 0) return;
            var obj = Selection.assetGUIDs[0];
            var path = AssetDatabase.GUIDToAssetPath(obj);
            if (!Directory.Exists(path))
                path = Path.GetDirectoryName(path);
            path += "/ShaderRuleConfig2.asset";
            var list = CreateInstance<ShaderRuleConfig>();
            AssetDatabase.CreateAsset(list, path);
            AssetDatabase.ImportAsset(path);
        }
        
        private static ShaderRuleConfig _instance;

        public static ShaderRuleConfig Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = AssetDatabase.LoadAssetAtPath<ShaderRuleConfig>(configPath);
                }
                return _instance;
            }
        }

        public static bool IsBulitInShader(string shaderTxt)
        {
            return IsTargetShader(shaderTxt, Instance.BuiltInRuleList);
        }
        
        public static bool IsURPShader(string shaderTxt)
        {
            return IsTargetShader(shaderTxt, Instance.URPRuleList);
        }
        
        private static bool IsTargetShader(string shaderTxt, List<string> rules)
        {
            foreach (var rule in rules)
            {
                if (Regex.IsMatch(shaderTxt, rule))
                {
                    return true;
                }
            }

            return false;
        }

    }
}