using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace BolygonTool.Check
{
    public class PackageCheckSetting : ScriptableObject
    {
        public string ReportFolderPath;
        public string PackageFolderPath;
        public string PackageName;
        public PackageCheckInfo CheckInfo;
        public int Index;
        public List<string> packageList;
        private const string SettingPath = "Assets/PackageCheckSetting.asset";
        public string ReportPath => string.IsNullOrEmpty(ReportFolderPath)? null : ReportFolderPath + "/PackageCheckResult.csv";

        private static PackageCheckSetting _instance;

        public static PackageCheckSetting Instance
        {
            get
            {
                if (_instance == null)
                    _instance = GetSetting();
                return _instance;
            }
        }

        private static PackageCheckSetting GetSetting()
        {
            if (File.Exists(SettingPath))
            {
                return AssetDatabase.LoadAssetAtPath<PackageCheckSetting>(SettingPath);
            }
            var setting = CreateInstance<PackageCheckSetting>();
            AssetDatabase.CreateAsset(setting, SettingPath);
            AssetDatabase.ImportAsset(SettingPath);
            return setting;
        }

        public void Refresh()
        {
            AssetDatabase.ForceReserializeAssets(new []{SettingPath}, ForceReserializeAssetsOptions.ReserializeAssets);
            AssetDatabase.ImportAsset(SettingPath);
        }
    }
}