﻿using System;
using System.Collections.Generic;
using Bolygon.BuildPlugin.Tool;

namespace BolygonTool.Check
{
    [Serializable]
    public class PackageCheckInfo
    {
        public string PackageId;
        public string PackageName;
        public UnsupportInfo UnsupportInfo;
        public List<PrefabCheckInfo> PrefabInfos;
        public List<MaterialCheckInfo> MaterialInfos;
    }

    [Serializable]
    public class UnsupportInfo
    {
        public bool HasScript;
        public bool HasUnSupportShader;

        public bool InVaild()
        {
            return HasScript || HasUnSupportShader;
        }
    }

    [Serializable]
    public class PrefabCheckInfo
    {
        public string Path;
        public List<MaterialCheckInfo> MaterialInfos;
        public List<string> Logs;
    }

    [Serializable]
    public class MaterialCheckInfo
    {
        public string Name;
        public string ShaderName;
        public ShaderType Type;
        public List<string> Logs;
    }
}