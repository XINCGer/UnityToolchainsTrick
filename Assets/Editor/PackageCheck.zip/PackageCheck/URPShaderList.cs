//---------------------------------------------------------------------------------------
// Author: chenxuan@bolygon.com
// Date: 2021-08-31 15:29:24
// Name: URPShaderList
//---------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace Bolygon.BuildPlugin.Tool
{
    public class URPShaderList : ScriptableObject
    {
        public string URPVersion;
        public List<string> URPShaderNameList;
        private const string urpPath = "Packages/com.unity.render-pipelines.universal";

        private const string configPath =
            "Packages/com.bolygon.build-plugin/BolygonTool/Check/WhiteLists/URPShaderList.asset";

        [MenuItem("Assets/Create/Shader/CreateURPShaderList", priority = 0)]
        public static void CreateURPShaderList()
        {
            if (Selection.assetGUIDs.Length <= 0) return;
            var obj = Selection.assetGUIDs[0];
            var path = AssetDatabase.GUIDToAssetPath(obj);
            if (!Directory.Exists(path))
                path = Path.GetDirectoryName(path);
            path += "/URPShaderList.asset";
            var list = CreateInstance<URPShaderList>();
            AssetDatabase.CreateAsset(list, path);
            AssetDatabase.ImportAsset(path);
            list.CheckURPInternalShader();
        }

        [ContextMenu("Check URP Shader")]
        public async void CheckURPInternalShader()
        {
            UnityEditor.PackageManager.Requests.ListRequest
                listRequest = UnityEditor.PackageManager.Client.List(true, true);
            await UniTask.WaitUntil(() => listRequest.IsCompleted).Timeout(new TimeSpan(0, 1, 0));
            var currentVersion = string.Empty;
            if (listRequest == null)
            {
                Debug.LogError("Not Request?!");
                return;
            }

            foreach (UnityEditor.PackageManager.PackageInfo packageInfo in listRequest.Result)
            {
                if (packageInfo.name == "com.unity.render-pipelines.universal")
                {
                    currentVersion = packageInfo.version;
                    break;
                }
            }

            if (currentVersion == URPVersion) return;
            URPVersion = currentVersion;
            URPShaderNameList = new List<string>();
            var guids = AssetDatabase.FindAssets("t:Shader", new string[] {urpPath});
            foreach (var guid in guids)
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                var shader = AssetDatabase.LoadAssetAtPath<Shader>(path);
                URPShaderNameList.Add(shader.name);
            }

            EditorUtility.SetDirty(this);
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
        }

        private static URPShaderList _instance;

        public static URPShaderList Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = AssetDatabase.LoadAssetAtPath<URPShaderList>(configPath);
                    _instance.CheckURPInternalShader();
                }

                return _instance;
            }
        }
    }
}