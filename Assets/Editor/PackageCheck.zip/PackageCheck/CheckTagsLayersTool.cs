using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEngine;

[Serializable]
public class TagsEtcSetting
{
    public List<string> Tags;
    public List<int> layerIds;
    public List<string> LayersName;
    public List<int> SortinglayerIds;
    public List<string> SortingLayersName;

    [NonSerialized]
    private Dictionary<int, string> _layers;
    public Dictionary<int, string> Layers
    {
        get 
        {
            if (_layers != null)
                return _layers;
            _layers = new Dictionary<int, string>();
            for (int i = 0; i < layerIds.Count; i++)
            {
                _layers.Add(layerIds[i], LayersName[i]);
            }
            return _layers;
        }
    }

    [NonSerialized]
    private Dictionary<int, string> _sortingLayers;
    public Dictionary<int, string> SortingLayers
    {
        get
        {
            if (_sortingLayers != null)
                return _sortingLayers;
            _sortingLayers = new Dictionary<int, string>();
            for (int i = 0; i < SortinglayerIds.Count; i++)
            {
                _sortingLayers.Add(SortinglayerIds[i], SortingLayersName[i]);
            }
            return _sortingLayers;
        }
    }
}

public class CheckTagsLayersTool
{
    public const string SettingFilePath = "Assets/Editor/PackageCheck/TagsEtcSetting.txt";
    private static TagsEtcSetting _saveSetting;
    public static TagsEtcSetting SaveSetting
    {
        get 
        {
            if (_saveSetting != null)
                return _saveSetting;
            if (!File.Exists(SettingFilePath)) return null;
            var json = File.ReadAllText(SettingFilePath);
            _saveSetting = JsonUtility.FromJson<TagsEtcSetting>(json);
            return _saveSetting;
        }
    }

    [MenuItem("Tools/Yahaha/BuildPlugin/Collect Tags&Layers",false,20)]
    public static void CollectionTagEtcSetting()
    {
        var setting = GetProjectSetting();
        var json = JsonUtility.ToJson(setting);
        Debug.LogWarning("Tags, Layers and Sortlayers Setting :\n" + json);
        var dirPath = Path.GetDirectoryName(SettingFilePath);
        if (!Directory.Exists(dirPath))
        {
            Directory.CreateDirectory(dirPath);
        }

        if (File.Exists(SettingFilePath) &&!EditorUtility.DisplayDialog("Warnning","The setting is exited, really override this��","OK","Cancel"))
        {
            return;
        }

        FileStream fs  = File.Open(SettingFilePath,FileMode.Create);
        try
        {
            StreamWriter sw = new StreamWriter(fs);
            sw.Write(json);
            sw.Flush();
        }
        catch (Exception e)
        {
            Debug.LogError(e.Message);
        }
        finally
        {
            fs.Close();
            AssetDatabase.Refresh();
        }
    }

    public static TagsEtcSetting GetProjectSetting()
    {
        var setting = new TagsEtcSetting();
        var tags = UnityEditorInternal.InternalEditorUtility.tags;
        setting.Tags = new List<string>(tags);

        var layers = UnityEditorInternal.InternalEditorUtility.layers;
        setting.LayersName = new List<string>(layers);
        setting.layerIds = new List<int>();
        for (int i = 0; i < layers.Length; i++)
        {
            var id = LayerMask.NameToLayer(layers[i]);
            setting.layerIds.Add(id);
        }

        var sortinglayers = SortingLayer.layers;
        setting.SortinglayerIds = new List<int>();
        setting.SortingLayersName = new List<string>();
        for (int i = 0; i < sortinglayers.Length; i++)
        {
            setting.SortinglayerIds.Add(sortinglayers[i].value);
            setting.SortingLayersName.Add(sortinglayers[i].name);
        }
        return setting;
    }

    public static bool CheckTagsEtcInGameObject(GameObject root,out List<GameObject> errorTags,out List<GameObject> errorLayers,out List<GameObject> errorSortingLayers)
    {
        bool hasError = false;
        errorTags = new List<GameObject>();
        errorLayers = new List<GameObject>();
        errorSortingLayers = new List<GameObject>();
        if (SaveSetting == null)
        {
            Debug.LogWarning($"No Exited :{SettingFilePath}!!!");
            return hasError;
        }
        var trans = root.GetComponentsInChildren<Transform>();
        for (int i = 0; i < trans.Length; i++)
        {
            if (!SaveSetting.Tags.Contains(trans[i].tag))
            {
                errorTags.Add(trans[i].gameObject);
                hasError = true;
            }
            if (SaveSetting.Layers.TryGetValue(trans[i].gameObject.layer, out var name))
            {
                if (name != LayerMask.LayerToName(trans[i].gameObject.layer))
                {
                    errorLayers.Add(trans[i].gameObject);
                    hasError = true;
                }
            }
            else
            {
                errorLayers.Add(trans[i].gameObject);
                hasError = true;
            }
        }

        var canvas = root.GetComponentsInChildren<Canvas>();
        for (int i = 0; i < canvas.Length; i++)
        {
            //if (canvas[i].renderMode == RenderMode.ScreenSpaceOverlay)
            //    continue;
            if (SaveSetting.SortingLayers.TryGetValue(SortingLayer.GetLayerValueFromID(canvas[i].sortingLayerID), out var name))
            {
                if (name != canvas[i].sortingLayerName)
                {
                    errorSortingLayers.Add(canvas[i].gameObject);
                    hasError = true;
                }
            }
            else
            {
                errorSortingLayers.Add(canvas[i].gameObject);
                hasError = true;
            }
        }

        return hasError;
    }

}

public enum ErrorTagsEtcType
{
    NoExit,
    WrongName,
}

public class ShowCheckTagEtcResultInProject : EditorWindow
{

    [MenuItem("Tools/Yahaha/BuildPlugin/Compare Tags&Layers",false,20)]
    public static void CheckTagsEtcOnProjectSetting()
    {
        var win = EditorWindow.GetWindow<ShowCheckTagEtcResultInProject>("Check Tag Etc. Result");
        win.Initial();
        win.Show();
    }

    private List<string> NoExitTags;
    private Dictionary<ErrorTagsEtcType, List<int>> errorLayers;
    private Dictionary<ErrorTagsEtcType, List<int>> errorSortingLayers;
    private TagsEtcSetting _nowSetting;
    private TagsEtcSetting _saveSetting => CheckTagsLayersTool.SaveSetting;

    public void Initial()
    {
        _nowSetting = CheckTagsLayersTool.GetProjectSetting();
        NoExitTags = new List<string>();
        for (int i = 0; i < _nowSetting.Tags.Count; i++)
        {
            if (!_saveSetting.Tags.Contains(_nowSetting.Tags[i]))
                NoExitTags.Add(_nowSetting.Tags[i]);
        }

        errorLayers = new Dictionary<ErrorTagsEtcType, List<int>>();
        CheckLayers(_nowSetting.Layers, _saveSetting.Layers, ref errorLayers);

        errorSortingLayers = new Dictionary<ErrorTagsEtcType, List<int>>();
        CheckLayers(_nowSetting.SortingLayers, _saveSetting.SortingLayers, ref errorSortingLayers);

    }

    Vector3 _scollPos = Vector3.zero;
    private void OnGUI()
    {
        bool showed = false;
        _scollPos = GUILayout.BeginScrollView(_scollPos);
        if (NoExitTags.Count > 0)
        {
            GUILayout.Label("Unsupported Tag:");
            foreach (var item in NoExitTags)
            {
                GUILayout.Label(item);
            }
            showed = true;
        }
        GUILayout.Space(10f);
        if (errorLayers.Count > 0)
        {
            GUILayout.Label("Layer:");
            ShowErrorLayer(errorLayers, _nowSetting.Layers, _saveSetting.Layers);
            GUILayout.Space(10f);
            showed = true;
        }

        if (errorSortingLayers.Count > 0)
        {
            GUILayout.Label("SortingLayer:");
            ShowErrorLayer(errorSortingLayers, _nowSetting.SortingLayers, _saveSetting.SortingLayers);
            showed = true;
        }

        if (!showed)
        {
            GUILayout.Label("This Project is clean !!!");
        }

        GUILayout.EndScrollView();
    }

    private void ShowErrorLayer(Dictionary<ErrorTagsEtcType, List<int>> errorlayers, Dictionary<int, string> nowlayers, Dictionary<int, string> saveLayers)
    {
        if (errorlayers.TryGetValue(ErrorTagsEtcType.WrongName, out var list))
        {
            GUILayout.Label("Layer Name Wrong ��");
            for (int i = 0; i < list.Count; i++)
            {
                GUILayout.Label($"id:{list[i]}\t the name��{nowlayers[list[i]]}\t support name��{saveLayers[list[i]]}");
            }
        }
        if (errorlayers.TryGetValue(ErrorTagsEtcType.NoExit, out var list2))
        {
            GUILayout.Label("Unsupported Layer:");
            for (int i = 0; i < list2.Count; i++)
            {
                GUILayout.Label($"id:{list2[i]}\t the name��{nowlayers[list2[i]]}");
            }
        }
    }

    private void CheckLayers(Dictionary<int, string> nowLayers, Dictionary<int, string> saveLayers, ref Dictionary<ErrorTagsEtcType, List<int>> errorList)
    {
        foreach (var layer in nowLayers)
        {
            if (saveLayers.TryGetValue(layer.Key, out var name))
            {
                if (name == layer.Value) continue;
                AddToDic(ref errorList, ErrorTagsEtcType.WrongName, layer.Key);
            }
            else
            {
                AddToDic(ref errorList, ErrorTagsEtcType.NoExit, layer.Key);
            }
        }
    }

    private void AddToDic(ref Dictionary<ErrorTagsEtcType, List<int>> errorDict, ErrorTagsEtcType error, int id)
    {
        if (errorDict == null)
        {
            errorDict = new Dictionary<ErrorTagsEtcType, List<int>>();
            errorDict.Add(error, new List<int> { id });
        }
        else if (errorDict.ContainsKey(error))
        {
            errorDict[error].Add(id);
        }
        else
            errorDict.Add(error, new List<int> { id });

    }

}
