using UnityEngine;
using System.IO;
using System;
using UnityEditor;

namespace Bolygon.BuildPlugin
{
    public static class CloudBuildLog
    {
        private static string m_filePath ;

        static CloudBuildLog()
        {
            m_filePath = Path.GetDirectoryName(Application.dataPath) + "/CloudBuildLog.txt";
            if (File.Exists(m_filePath))
                File.Delete(m_filePath);
        }

        public static void Log(object obj)
        {
            File.AppendAllText(m_filePath, $"[{DateTime.Now.ToString()}]:{obj}\n");
            Debug.Log(obj);
        }
        public static void Warning(object obj)
        {
            File.AppendAllText(m_filePath, $"Warnning[{DateTime.Now.ToString()}]:{obj}\n");
            Debug.LogWarning(obj);
        }
        public static void Error(object obj, bool quitUnity = true, int errorCode = 99)
        {
            Debug.LogError(obj);
            var errorMsg = $"Error[{DateTime.Now.ToString()}]:{obj}\n";
            var exp = new Exception(errorMsg);
            File.AppendAllText(m_filePath, errorMsg);
            if (quitUnity && Application.isBatchMode)
            {
                EditorApplication.Exit(errorCode);
            }
        }
    }
}

